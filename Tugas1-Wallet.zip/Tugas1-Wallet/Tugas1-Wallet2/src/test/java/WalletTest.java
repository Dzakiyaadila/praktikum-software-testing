import org.example.Wallet;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

//tambahin tag order
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class WalletTest {

    //declare objek, biar bis alangsung dipakai oleh semua class
    private Wallet wallet;

    @BeforeAll
    static void initClass() {
        System.out.println("Testing dimulai");
    }

    @BeforeEach
    void setUp() {
        wallet = new Wallet("Zakki", 10000);
        System.out.println("Setting up wallet baru");
    }


    @Test
    @Order(1)
    void testConstructor() {
        assertEquals("Zakki", wallet.getOwner());
        assertEquals(10000, wallet.getCash());
        assertNotNull(wallet.getCards());
    }

    @Test
    @Order(2)
    void testDeposit() {
        wallet.deposit(5000);
        assertEquals(15000, wallet.getCash());
    }

    @Test
    @Order(3)
    void testWithdraw() {
        wallet.withdraw(4000);
        assertEquals(6000, wallet.getCash());
    }

    @Test
    @Order(4)
    void testWithdrawMelebihiSaldo() {
        assertThrows(IllegalArgumentException.class, () -> {
            wallet.withdraw(20000);
        });
    }

    @Test
    @Order(5)
    void testAddCard() {
        wallet.addCard("Visa");
        assertTrue(wallet.getCards().contains("Visa"));
    }

    @Test
    @Order(6)
    void testRemoveCard() {
        wallet.addCard("MasterCard");
        wallet.removeCard("MasterCard");
        assertFalse(wallet.getCards().contains("MasterCard"));
    }

    //cleaing up tiap setelah testing
    @AfterEach
    void tearDown() {

        wallet = null;
        System.out.println("cleaning up objek wallet");
    }

    @AfterAll
    static void afterAll() {
        System.out.println("Berhentikan seluruh testing");
    }
}